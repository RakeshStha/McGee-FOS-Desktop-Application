
package CLient;

import java.rmi.Naming;
import java.rmi.RemoteException;
import Server.RMI_Interface;
import Server.Cls_RMI_Interface_Imp;

public class CLs_Client
{
    
    public static void main (String args[]) throws RemoteException
    {
        try 
        {
           RMI_Interface RI = (RMI_Interface) Naming.lookup("rmi://192.168.1.71:9000/RMI");   
           System.out.println(RI.sum(30, 10));
          
        } 
        catch (Exception e) 
        {
            System.out.println("Connection error" + e);
        }
    }
    
}
