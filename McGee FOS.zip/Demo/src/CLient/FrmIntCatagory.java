package CLient;

import Server.Cls_DBConnection;
import Server.Cls_RMI_Interface_Imp;
import Server.RMI_Interface;
import Server.Cls_RMI_Interface_Imp;
import java.io.EOFException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class FrmIntCatagory extends javax.swing.JInternalFrame {
    
     

    static String Cat_name;
    static String Cat_Desc;

    public FrmIntCatagory() {
        initComponents();
    }

    public void ClsTestVlue() {
        //TxtCatagoryID.setText("");
        FoodName.setText("");
       
        Price.setValue("");
        Desc.setText("");

    }
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel8 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Desc = new javax.swing.JTextArea();
        BtnCancel = new javax.swing.JButton();
        BtnAddCatagory = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        FoodName = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        Type = new javax.swing.JComboBox<>();
        Price = new javax.swing.JSpinner();
        jLabel1 = new javax.swing.JLabel();

        setClosable(true);
        setTitle("FOS System Add Catagory");
        setMinimumSize(new java.awt.Dimension(706, 509));
        setPreferredSize(new java.awt.Dimension(705, 510));
        getContentPane().setLayout(null);

        jLabel8.setFont(new java.awt.Font("Times New Roman", 0, 48)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 204, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("McGee Resturant");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(0, 0, 680, 70);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 204, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Add Food Item");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(190, 70, 300, 40);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 204, 255));
        jLabel2.setText("Price");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(110, 250, 166, 30);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 204, 255));
        jLabel3.setText("Catagory Description");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(110, 320, 166, 29);

        Desc.setBackground(new java.awt.Color(204, 204, 204));
        Desc.setColumns(20);
        Desc.setRows(5);
        jScrollPane1.setViewportView(Desc);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(360, 300, 280, 90);

        BtnCancel.setBackground(new java.awt.Color(204, 204, 204));
        BtnCancel.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        BtnCancel.setText("Cancel");
        BtnCancel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(BtnCancel);
        BtnCancel.setBounds(170, 410, 98, 37);

        BtnAddCatagory.setBackground(new java.awt.Color(204, 204, 204));
        BtnAddCatagory.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        BtnAddCatagory.setText("Add Food");
        BtnAddCatagory.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnAddCatagory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnAddCatagoryActionPerformed(evt);
            }
        });
        getContentPane().add(BtnAddCatagory);
        BtnAddCatagory.setBounds(370, 410, 154, 37);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 204, 255));
        jLabel6.setText("Food Name ");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(110, 170, 166, 30);

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 204, 255));
        jLabel7.setText("Food Name ");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(110, 170, 166, 30);

        FoodName.setBackground(new java.awt.Color(204, 204, 204));
        FoodName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FoodNameActionPerformed(evt);
            }
        });
        getContentPane().add(FoodName);
        FoodName.setBounds(360, 170, 192, 28);

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 204, 255));
        jLabel9.setText("Type ");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(110, 210, 166, 30);

        Type.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Food Item", "Beverage" }));
        getContentPane().add(Type);
        Type.setBounds(360, 210, 190, 30);
        getContentPane().add(Price);
        Price.setBounds(360, 250, 190, 30);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\civil\\Desktop\\java Background\\wood.jpg")); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 690, 480);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtnAddCatagoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnAddCatagoryActionPerformed

        Cat_name = FoodName.getText();
        Cat_Desc = Desc.getText();

        if (Cat_name.equals(""))
        {
            JOptionPane.showMessageDialog(null, " Catagory Name can not be Blank !!! ");
        } 
        else 
        {

            try {

                RMI_Interface RI = new Cls_RMI_Interface_Imp();
                RI.AddCatagory(FoodName.getText(), Type.getSelectedItem().toString(), Price.getValue().toString(), Desc.getText());
                JOptionPane.showMessageDialog(null, "New Catagory added Successfully !!!");
                ClsTestVlue();

            } catch (Exception e) {
                // JOptionPane.showMessageDialog(null, "Error Occured !!!"+e);
                System.out.println("Error occured : " + e);

            }

        }
    }//GEN-LAST:event_BtnAddCatagoryActionPerformed

    private void FoodNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FoodNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FoodNameActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnAddCatagory;
    private javax.swing.JButton BtnCancel;
    private javax.swing.JTextArea Desc;
    private javax.swing.JTextField FoodName;
    private javax.swing.JSpinner Price;
    private javax.swing.JComboBox<String> Type;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
