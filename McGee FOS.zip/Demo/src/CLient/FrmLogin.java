
package CLient;
import Server.Cls_Login;
import java.rmi.Naming;
import javax.swing.JOptionPane;
import Server.RMI_Interface;
import Server.Cls_RMI_Interface_Imp;
import CLient.FrmLogin;
import CLient.MainPage;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import CLient.Register;



public class FrmLogin extends javax.swing.JFrame {
    
    Cls_Login Cl = new Cls_Login();
            
    static String user, pwd, role;

    public FrmLogin() {
        initComponents();
    }

public void close(){
        WindowEvent closeWindow  = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
    }    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        TxtUserName = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtPwd = new javax.swing.JPasswordField();
        BtnCancel = new javax.swing.JButton();
        BtnLogin = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Demo User Login");
        setMinimumSize(new java.awt.Dimension(760, 380));
        getContentPane().setLayout(null);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 204, 255));
        jLabel2.setText("User Name");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(260, 90, 124, 30);
        getContentPane().add(TxtUserName);
        TxtUserName.setBounds(470, 90, 225, 30);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 204, 255));
        jLabel3.setText("Password ");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(260, 140, 124, 30);
        getContentPane().add(txtPwd);
        txtPwd.setBounds(470, 140, 225, 34);

        BtnCancel.setBackground(new java.awt.Color(204, 204, 204));
        BtnCancel.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        BtnCancel.setText("Cancel");
        BtnCancel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCancelActionPerformed(evt);
            }
        });
        getContentPane().add(BtnCancel);
        BtnCancel.setBounds(410, 220, 123, 35);

        BtnLogin.setBackground(new java.awt.Color(204, 204, 204));
        BtnLogin.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        BtnLogin.setText("Login");
        BtnLogin.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnLoginActionPerformed(evt);
            }
        });
        getContentPane().add(BtnLogin);
        BtnLogin.setBounds(560, 220, 115, 35);

        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jButton1.setText("Registration");
        jButton1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(210, 220, 163, 35);

        jLabel8.setFont(new java.awt.Font("Times New Roman", 0, 48)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 204, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("McGee Resturant");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(160, 0, 580, 70);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\civil\\Desktop\\java Background\\wood.jpg")); // NOI18N
        jLabel1.addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                jLabel1ComponentAdded(evt);
            }
        });
        getContentPane().add(jLabel1);
        jLabel1.setBounds(160, 0, 580, 330);

        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\civil\\Desktop\\java Background\\logo copy.png")); // NOI18N
        getContentPane().add(jLabel4);
        jLabel4.setBounds(0, 0, 160, 330);

        setSize(new java.awt.Dimension(753, 368));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BtnLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnLoginActionPerformed
               
          try 
          {
            
               user = TxtUserName.getText();
                pwd = txtPwd.getText();
           
            RMI_Interface RI = (RMI_Interface) Naming.lookup("rmi://192.168.1.71:9000/RMI");
            System.out.println(RI.sum(30, 10));
                     
            Cls_RMI_Interface_Imp RIM = new Cls_RMI_Interface_Imp();
          //  RMI_Interface RIM = new Cls_RMI_Interface_Imp();

            RIM.login(user, pwd);

            //JOptionPane.showMessageDialog(null, "Invalid User Name and Passsword.\nPlease try another username.");

        } catch (Exception e) {
            System.out.println("Connection error" + e);
        }

        
        
        
       
        /*
       if(TxtUserName.getText()!="")
       {
           
              
       System.out.println("User Name :  "+user);
       System.out.println("Password  : "+pwd); 
    
       MainPage  MP = new MainPage();
       MP.setVisible(true);
       
       }
       else
       {
          JOptionPane.showMessageDialog(this,"User Name and Passsword Can not be Blank !!!");
       }
       
       */
        
    }//GEN-LAST:event_BtnLoginActionPerformed

    private void BtnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCancelActionPerformed
       
        JOptionPane.showMessageDialog(this, "Are you sure want to exit !!! ");
        System.exit(0);
        
    }//GEN-LAST:event_BtnCancelActionPerformed

    private void jLabel1ComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_jLabel1ComponentAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel1ComponentAdded

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
         //close();
         this.setVisible(false);
        Register r = new Register();
        r.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

   
    public static void main(String args[]) {
   
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnCancel;
    private javax.swing.JButton BtnLogin;
    private javax.swing.JTextField TxtUserName;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPasswordField txtPwd;
    // End of variables declaration//GEN-END:variables
}
