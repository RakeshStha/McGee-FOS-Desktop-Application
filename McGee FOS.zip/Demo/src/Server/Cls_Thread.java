
package Server;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Cls_Thread 
{
    
    public static void main(String[] args) throws IOException
    {
    
      int port = 7000;
        try 
         {
             ServerSocket server = new ServerSocket(port);
             System.out.println("server is running on : "+ port);
             while(true)
             {
              
                Socket client =server.accept();
                System.out.println("Connection request from "+ client.getInetAddress().getHostAddress());
                
                
                 clsClientListener listener = new clsClientListener(client);
                 listener.start();
             
                /*
                 PrintStream ps = new PrintStream(client.getOutputStream());
                 ps.println("Welcome to Chat Program ");
                 ps.println("Enter your Name :");
                 
                 BufferedReader reader = new BufferedReader( new InputStreamReader(client.getInputStream()));
                 String name = reader.readLine();
                 System.out.println("Hello " + name);
                 
               */
                 
             }
         }
         catch(Exception e)
         {
             System.out.println("Error  "+e.getMessage());
         }
          
    
}
}
