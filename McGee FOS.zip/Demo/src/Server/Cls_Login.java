
package Server;


public class Cls_Login {
    
  String UserName;
  String password;
  String UserRole;

       

    public String getUserName() {
        return UserName;
    }

    public String getPassword() {
        return password;
    }

    public String getUserRole() {
        return UserRole;
    }

    public void setUserName(String UserName) {
        this.UserName = UserName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUserRole(String UserRole) {
        this.UserRole = UserRole;
    }
  
  
  
  
    
}
