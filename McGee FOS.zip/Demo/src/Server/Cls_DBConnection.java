
package Server;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Cls_DBConnection
{
     public static Connection  DBConn()
   {
      Connection con = null;
      Statement stm  = null ;
      
      try
      {
         Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
        // line below needs to be modified to include the database name, user, and password (if any)
          con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=FOSDB_2021;user=sa;password=b_k;");
          
          //con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=FOSDB;Trusted_Connection=True;");
          
          System.out.println("Connected to database !");
      }
      catch(Exception ex)
      {
          System.out.println("DB connection error :"+ ex);
      }
         
      return con;
   }

    public CallableStatement prepareCall(String call_SP_BillGenerate) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
