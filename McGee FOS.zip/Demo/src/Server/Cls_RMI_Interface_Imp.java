package Server;

import CLient.MainPage;
import CLient.FrimUsers;
import CLient.FrmMenu;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class Cls_RMI_Interface_Imp extends  UnicastRemoteObject implements RMI_Interface {
   
    Cls_DBConnection conn = new Cls_DBConnection();
    Connection cnn = conn.DBConn();
    PreparedStatement pst = null;
    
    static String status;
    public static String CustID;
    public static String CustomerName;
    public static String UserRole;
    
    public Cls_RMI_Interface_Imp() throws RemoteException {
        super();
    }
    public int sum(int a, int b) 
    {
       return  a + b;
    }
    
    
    public void login(String user, String Pwd) {

        String sql = "select * from tblCustomer where UserName='" + user.toString() + "' and Pwd ='" + Pwd.toString() + "' ";

        try {
         
            pst = cnn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            int counter = 0;
            if (rs.next()) {
                counter++;

            }
            if (counter > 0)
            {
                CustID = rs.getString("CustomerID");
                CustomerName = rs.getString("UserName");
                UserRole = rs.getString("UserRole");
                 if ( "Customer".equals(UserRole)){
                     FrmMenu fm = new FrmMenu();
                     fm.setVisible(true);    
                 }
                 else {
                     MainPage mp = new MainPage();
                     mp.setVisible(true);
                 }
            } else {
                JOptionPane.showMessageDialog(null, "User Name or Password Invalid !!!  .\nPlease try another username.");
            }

        } catch (SQLException ex) {
            System.out.println("SQL Error !!" + ex);
        }

    }
    
   
    
    public String AddCatagory(String FoodName , String Type , String Price , String Desc)
    {
        
         String sql = "insert into Catagory (FoodName, FoodType, Price,CatagoryDescription) values ('" + FoodName.toString() + "', '" + Type.toString() + "', '" + Price.toString() + "', '" + Desc.toString() + "' )";
             
        try 
        {
         
            pst = cnn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
           
             JOptionPane.showMessageDialog(null, "New catagory Added Successfull !!"+ FoodName);
                            
           

        } 
        catch (SQLException ex)
        {
            System.out.println("SQL Error !!" + ex);
        }
        
        return null;
       
    }
    
    
     public String AddCustomer (String FirstName , String LastName, String UserName, String Pwd, String Country, String Addresses,  String IC_Passport_number, String Phone,String Mobile, String EmailAddress, String Remarks, String UserRole ) 
     {
    
        
         String sql = "insert into tblCustomer (FirstName,LastName,UserName,Pwd,Country,Addresses,IC_Passport_number,Phone,Mobile,EmailAddress,Remarks,UserRole) values ('" + FirstName.toString() + "','" + LastName.toString() + "','"+UserName.toString()+"','"+Pwd.toString()+"','"+Country.toString()+"','"+Addresses.toString()+"','"+IC_Passport_number.toString()+"','"+Phone.toString()+"','"+Mobile.toString()+"','"+EmailAddress.toString()+"','"+Remarks.toString()+"','"+UserRole.toString()+"' )";
             
        try 
        {
         
            pst = cnn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
           
             JOptionPane.showMessageDialog(null, "New catagory Added Successfull !!"+CustomerName);
                            
           

        } 
        catch (SQLException ex)
        {
            System.out.println("SQL Error !!" + ex);
        }
        
        return null;
       
}
    public String Registration (String FirstName , String LastName, String UserName, String Pwd, String Country, String Addresses,  String IC_Passport_number, String Phone,String Mobile, String EmailAddress) 
     {
         String username = UserName;
//          String sql = "select * from tblCustomer where UserName='" + username.toString() + "' ";
//
//        try {
//         
//            pst = cnn.prepareStatement(sql);
//            ResultSet rs = pst.executeQuery();
//            int counter = 0;
//            if (rs.next()) {
//                counter++;
//
//            }
//            if (counter > 0)
//            {
//                
//                CustomerName = rs.getString("UserName");
//                
//                 if ( CustomerName.equals(username)){
//                     JOptionPane.showMessageDialog(null, "Username already defined");    
//                 }
//                 else {
//                     //For inserting data into database
//        
//                        String insrt = "insert into tblCustomer (FirstName,LastName,UserName,Pwd,Country,Addresses,IC_Passport_number,Phone,Mobile,EmailAddress,Remarks,UserRole) values ('" + FirstName.toString() + "','" + LastName.toString() + "','"+UserName.toString()+"','"+Pwd.toString()+"','"+Country.toString()+"','"+Addresses.toString()+"','"+IC_Passport_number.toString()+"','"+Phone.toString()+"','"+Mobile.toString()+"','"+EmailAddress.toString()+"','None', 'Customer' )";
//
//                       try 
//                       {
//
//                           pst = cnn.prepareStatement(insrt);
//                           ResultSet rp = pst.executeQuery();
//
//                            JOptionPane.showMessageDialog(null, "New Customer Added Successfull !!"+CustomerName);
//
//
//
//                       } 
//                       catch (SQLException ex)
//                       {
//                           System.out.println("SQL Error !!" + ex);
//                       }
//        
//                 }
//            } else {
//                JOptionPane.showMessageDialog(null, "User Name or Password Invalid !!!  .\nPlease try another username.");
//            }
//
//        } catch (SQLException ex) {
//            System.out.println("SQL Error !!" + ex);
//        }
         
         
         
         
         
         
         
         
         //For inserting data into database
        
         String sql = "insert into tblCustomer (FirstName,LastName,UserName,Pwd,Country,Addresses,IC_Passport_number,Phone,Mobile,EmailAddress,Remarks,UserRole) values ('" + FirstName.toString() + "','" + LastName.toString() + "','"+UserName.toString()+"','"+Pwd.toString()+"','"+Country.toString()+"','"+Addresses.toString()+"','"+IC_Passport_number.toString()+"','"+Phone.toString()+"','"+Mobile.toString()+"','"+EmailAddress.toString()+"','None', 'Customer' )";
        
        try 
        {
   
            pst = cnn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
           
             JOptionPane.showMessageDialog(null, "New Customer Added Successfull !!"+CustomerName);
                            
           

        } 
        catch (SQLException ex)
        {
            System.out.println("SQL Error !!" + ex);
        }
//        
        return null;
       
}


public String OrderFood(String CustomerName, String Address, String Qty, String FoodItem, String Rate, String OrderStatus, String Remarks)
    {
         //For inserting data into database
        
         String sql = "insert into CustomerOrderFood (CustomerName,Address,Qty,FoodItem,Beverage,Rate,OrderStatus,Remarks) values ('" + CustomerName.toString() + "','" + Address.toString() + "','"+ Qty.toString()+"','"+ FoodItem.toString()+"','None','"+ Rate.toString()+"','"+ OrderStatus.toString()+"','"+ Remarks.toString()+"' )";
        
        try 
        {
   
            pst = cnn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
           
             JOptionPane.showMessageDialog(null, "Order Added Successfull !!"+CustomerName);
                            
           

        } 
        catch (SQLException ex)
        {
            System.out.println("SQL Error !!" + ex);
        }
//        
        return null;
    }

    public String OrderBeverage(String CustomerName, String Address, String Qty, String Beverage, String Rate, String OrderStatus, String Remarks)
    {
         //For inserting data into database
        
          String sql = "insert into CustomerOrderFood (CustomerName,Address,Qty,FoodItem,Beverage,Rate,OrderStatus,Remarks) values ('" + CustomerName.toString() + "','" + Address.toString() + "','"+ Qty.toString()+"' ,'None', '"+ Beverage.toString()+"','"+ Rate.toString()+"','"+ OrderStatus.toString()+"','"+ Remarks.toString()+"' )";
        
        try 
        {
   
            pst = cnn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
           
             JOptionPane.showMessageDialog(null, "Order Added Successfull !!"+CustomerName);
                            
           

        } 
        catch (SQLException ex)
        {
            System.out.println("SQL Error !!" + ex);
        }
//        
        return null;
    }
    
}