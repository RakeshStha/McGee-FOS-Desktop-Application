
package Server;

import java.rmi.Remote;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;



public class Cls_Server 
{
    
    public static void main(String args[]) 
   {
       try
       {
            Registry registry;
            //creating server port
             registry = LocateRegistry.createRegistry(9000); 
            //implementation
          
                     
            
            RMI_Interface rmi_inter =  new Cls_RMI_Interface_Imp();
           // Rmi_Interface  rmi_inter = new Rmi_Interface_Implement();
            registry.rebind("RMI", (Remote) rmi_inter);
           // Naming.rebind("rmi_inter" ,rmi_inter);
            
            System.out.println("Server is running ...........");
            
                            
                             
           
       }
       catch(Exception Ex)
       {
           System.out.println("Error occured !" + Ex);
       }
           
   }
    
}
