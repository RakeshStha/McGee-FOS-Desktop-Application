
package Server;

import java.rmi.RemoteException;
import java.rmi.*;


public interface RMI_Interface extends Remote
{
    public int sum(int x ,int y ) throws RemoteException; 
    
    public void login(String user , String Pwd) throws RemoteException;
    
    public String AddCatagory(String FoodName , String Type , String Price , String Desc) throws RemoteException;
    
    public String AddCustomer (String FirstName , String LastName, String UserName, String Pwd, String Country, String Addresses,  String IC_Passport_number, String Phone,String Mobile, String EmailAddress, String Remarks, String UserRole  ) throws RemoteException;

     public String Registration (String FirstName , String LastName, String UserName, String Pwd, String Country, String Addresses,  String IC_Passport_number, String Phone,String Mobile, String EmailAddress  ) throws RemoteException;

     public String OrderFood (String CustomerName, String Address, String Qty, String FoodItem, String Rate, String OrderStatus, String Remarks) throws RemoteException;
     
      public String OrderBeverage (String CustomerName, String Address, String Qty, String Beverage, String Rate, String OrderStatus, String Remarks) throws RemoteException;

//     public void AddCata(String user , String Pwd) throws RemoteException;

}
