
package Server;
import java.net.Socket;
import java.io.PrintStream;
import java.io.BufferedReader;
import java.io.BufferedInputStream;
import java.io.InputStreamReader;


public class clsClientListener extends Thread{
    
    private Socket client;
    
    public clsClientListener(Socket client)
    {
        this.client = client;
    }
    @Override
    public void run() {
        super.run(); 
       try
         {
                 PrintStream ps = new PrintStream(client.getOutputStream());
                 ps.println("Welcome to Chat Program ");
                 ps.println("Enter you Name :");
                 BufferedReader reader = new BufferedReader( new InputStreamReader(client.getInputStream()));
                 String name = reader.readLine();
                 System.out.println("Hello " + name);
                 
                 while(!isInterrupted())
                 {
                     String msg = reader.readLine();
                     ps.println(msg);
                 }
         }
         catch(Exception ioe)
         {
             
         }
         }
    
    
    
}
